package com.Elearning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElearningSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElearningSystemApplication.class, args);
		System.out.println("Ok............");
	}

}
