// import { DragDirective } from './drag.directive';

// describe('DragDirective', () => {
//   it('should create an instance', () => {
//     const directive = new DragDirective();
//     expect(directive).toBeTruthy();
//   });
// });
